package com.foodDonation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.foodDonation.entity.Feedback;
import com.foodDonation.repository.Feedbackrepository;

@Controller
public class FeedbackController {
    @Autowired
    private Feedbackrepository feedbackRepository;
    
    

    @GetMapping("/feedback")
    public String feedbackPage(Model model) {
        model.addAttribute("feedback", new Feedback());
        return "feedback";
    }
    
    String mail=UserController.name;

    @PostMapping("/feedback")
    public String submitFeedback(@ModelAttribute Feedback feedback,
                                 Model model) {
    	Feedback f=new Feedback();
    	f.setMessage(feedback.getMessage());
    	f.setUser(mail);
        feedbackRepository.save(f);
        model.addAttribute("success", "Feedback submitted successfully!");
        return "feedback";
    }

 
}
