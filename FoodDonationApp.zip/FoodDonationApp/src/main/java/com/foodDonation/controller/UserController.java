package com.foodDonation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.foodDonation.entity.User;
import com.foodDonation.service.EmailService;
import com.foodDonation.service.UserService;

@Controller
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private EmailService emailService;
    String mail;
    static String name;
    @GetMapping("/register")
    public String registerPage(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user, Model model) {
        String otp = userService.generateOtp();
        user.setOtp(otp);
        user.setVerified(false);
        userService.save(user);
        mail=user.getEmail();
        emailService.sendOtp(user.getEmail(), otp);
        model.addAttribute("email", user.getEmail());
        return "otp";
    }
    
    @GetMapping("main")
    public String getMain() {
    	return "main";
    }

    @PostMapping("/verify-otp")
    public String verifyOtp(@RequestParam String otp,
                            Model model) {

        User user = userService.findByEmail(mail);

        if (user != null && user.getOtp().equals(otp)) {
            user.setVerified(true);
            userService.save(user);
            return "login";
        }

        model.addAttribute("error", "Invalid OTP");
        
        return "otp";
    }

    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String loginUser(@RequestParam String email,
                            @RequestParam String password,
                            Model model) {

        User user = userService.findByEmail(email);

        if (user != null &&
            user.getPassword().equals(password)) {
        	name=user.getName();
            return "main";
        }

        model.addAttribute("error", "Invalid Credentials");
        return "login";
    }
}


