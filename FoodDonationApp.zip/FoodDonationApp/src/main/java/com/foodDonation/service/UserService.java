package com.foodDonation.service;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foodDonation.entity.User;
import com.foodDonation.repository.UserRepository;

@Service
public class UserService {
	@Autowired
    private UserRepository userRepository;

    public void save(User user) {
        userRepository.save(user);
    }

    public User findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public String generateOtp() {
        return String.valueOf(100000 + new Random().nextInt(900000));
    }

}
