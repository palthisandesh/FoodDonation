package com.foodDonation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.foodDonation.entity.Feedback;

public interface Feedbackrepository extends JpaRepository<Feedback, Long> {

}
