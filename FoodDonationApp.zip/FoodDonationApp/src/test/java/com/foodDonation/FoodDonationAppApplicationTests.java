package com.foodDonation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodDonationAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
